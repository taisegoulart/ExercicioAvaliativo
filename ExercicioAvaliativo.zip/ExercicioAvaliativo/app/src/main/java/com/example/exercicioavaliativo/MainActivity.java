package com.example.exercicioavaliativo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    private EditText txtNomeMedicamento;
    private EditText txtDoseMedicamento;
    private Spinner txtTurnos; //array do spinner

    private RadioGroup txtRadioGroup;
    private CheckBox txtDiasUteis;
    private CheckBox txtFinaisDeSemana;
    RadioButton radioButtonSelected;
    private Button btnEnviarForm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNomeMedicamento = findViewById(R.id.editTextText);
        txtDoseMedicamento = findViewById(R.id.editTextNumberDecimal);
        txtTurnos = findViewById(R.id.spinnerTurnos);
        txtRadioGroup = findViewById(R.id.radioGroup);
        txtDiasUteis= findViewById(R.id.checkBox12);
        txtFinaisDeSemana = findViewById(R.id.checkBox13);
        btnEnviarForm = findViewById(R.id.button);

        btnEnviarForm.setOnClickListener(new View.OnClickListener(){
       @Override
        public void onClick (View v){

           //Obtendo os dados dos elementos na UI
           String NomeMedicamento = txtNomeMedicamento.getText().toString();
           double DoseMedicamento = Double.parseDouble(txtDoseMedicamento.getText().toString());
           String Turnos = txtTurnos.getSelectedItem().toString();
           boolean DiasUteis = txtDiasUteis.isChecked();
           boolean FinaisDeSemana = txtFinaisDeSemana.isChecked();
           int selectedRadioButtonId = txtRadioGroup.getCheckedRadioButtonId();

           //Encontrando o RadioButton selecionado
           if(selectedRadioButtonId != -1){ //se é -1 significa que nada foi selecionado?
               radioButtonSelected =findViewById(selectedRadioButtonId);
           }

           //Criando intent para transferir os dados para a outra atividade
           Intent intent = new Intent (MainActivity.this, RespostasFormulario.class);
           intent.putExtra("NomeMedicamento", NomeMedicamento);
           intent.putExtra("DoseMedicamento", DoseMedicamento);
           intent.putExtra("Turnos", Turnos);
           if (radioButtonSelected != null){
               intent.putExtra("EsqueceMedicamento", radioButtonSelected.getText().toString());
           }
           startActivity(intent);


       }
        });

    }

}


