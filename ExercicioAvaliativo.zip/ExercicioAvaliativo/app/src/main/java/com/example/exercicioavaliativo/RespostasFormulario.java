package com.example.exercicioavaliativo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;



public class RespostasFormulario extends AppCompatActivity {

    TextView textViewNomeMedicamento;
    TextView textViewDoseMedicamento;
    TextView textViewTurnos;
    TextView textViewEsqueceMedicamento;
    TextView textViewQuaisDiasToma;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_respostas_formulario);

        textViewNomeMedicamento = findViewById(R.id.RespostaNomeMedicamento);
        textViewDoseMedicamento = findViewById(R.id.RespostaDose);
        textViewTurnos = findViewById(R.id.RespostaTurnos);
        textViewEsqueceMedicamento = findViewById(R.id.RespostaEsquece);
        textViewQuaisDiasToma = findViewById(R.id.RespostaDias);

// Receber os dados do Intent
        String NomeMedicamento = getIntent().getStringExtra("NomeMedicamento");
        double DoseMedcamento = getIntent().getDoubleExtra("DoseMedicamento", 0); // 0 é o valor padrão se não houver nada passado
        String Turnos = getIntent().getStringExtra("Turnos");
        boolean DiasUteis = getIntent().getBooleanExtra("DiasUteis", false);
        boolean FinaisDeSemana = getIntent().getBooleanExtra("FinasDeSemana", false);
        String  EsqueceMedicamento = getIntent().getStringExtra("QuandoEsquece");

// Construir a string do checkbox?
        StringBuilder diasDaSemanaQueTomaMedicamento = new StringBuilder();
        if (DiasUteis) {
            diasDaSemanaQueTomaMedicamento.append(getString(R.string.DiasUteis)).append(", ");
        }
        if (FinaisDeSemana) {
            diasDaSemanaQueTomaMedicamento.append(getString(R.string.FinaisDeSemana)).append(", ");
        }

// Remover a vírgula final, se houver
        if (diasDaSemanaQueTomaMedicamento.length() > 0) {
            diasDaSemanaQueTomaMedicamento.deleteCharAt(diasDaSemanaQueTomaMedicamento.length() - 2);
        }

// Exibir os dados na interface do usuário
    textViewNomeMedicamento.setText(NomeMedicamento);
    textViewDoseMedicamento.setText(String.valueOf(DoseMedcamento));
    textViewTurnos.setText(Turnos);
    textViewQuaisDiasToma.setText(diasDaSemanaQueTomaMedicamento.toString());
    textViewEsqueceMedicamento.setText(EsqueceMedicamento);

    }



}